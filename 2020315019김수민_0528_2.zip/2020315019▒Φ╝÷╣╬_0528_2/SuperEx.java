
/**
 * SuperEx 클래스의 설명을 작성하세요.
 *
 * @author (작성자 이름)
 * @version (버전 번호 또는 작성한 날짜)
 */
public class SuperEx
{
    public static void main(String[] args){
        ColorPoint cp = new ColorPoint(5,6,"blue");
        cp.showColorPoint();
    }
}
